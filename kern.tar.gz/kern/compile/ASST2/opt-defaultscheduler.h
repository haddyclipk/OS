/* Automatically generated; do not edit */
#ifndef _OPT_DEFAULTSCHEDULER_H_
#define _OPT_DEFAULTSCHEDULER_H_
#define OPT_DEFAULTSCHEDULER 1
#endif /* _OPT_DEFAULTSCHEDULER_H_ */
